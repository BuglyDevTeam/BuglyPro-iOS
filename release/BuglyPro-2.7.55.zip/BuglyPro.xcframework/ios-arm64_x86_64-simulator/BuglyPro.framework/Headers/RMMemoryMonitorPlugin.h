//
//  RMMemoryMonitor.h
//  RMMonitor
//
//  Created by Cass on 2018/4/9.
//  Copyright © 2018年 com.tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 * 内存监控模块
 */
@interface RMMemoryMonitorPlugin : NSObject


@end
