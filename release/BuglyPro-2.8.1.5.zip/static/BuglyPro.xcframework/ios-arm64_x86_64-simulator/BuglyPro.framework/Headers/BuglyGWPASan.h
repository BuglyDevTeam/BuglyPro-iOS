//
//  BuglyGWPASan.h
//  RaftMonitor
//
//  Created by Tianwu Wang on 2024/8/19.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BuglyGWPASan : NSObject

@end

NS_ASSUME_NONNULL_END
